Add states here that should be run only once after the first installation of the openmediavault Debian package.
The scripts can be used to prepare the system to the desired requirements.
